// import Main from './components/Main';
import MasterPage from './components/MasterPage';

function App() {
  return (
    // <Main/>  
    <MasterPage/>  
  );
}

export default App;
