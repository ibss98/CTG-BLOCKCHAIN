export const pinataConfig = {
  root: 'https://api.pinata.cloud',
  headers: { 
    'pinata_api_key': 'faef294b4014bc52900e',
    'pinata_secret_api_key': '9ec3996ad549f6bddca514d05a7a6984e91881591bdc54bed97b40ee06c68d0c' 
  }
};